def suma (x,y):
    return x+y