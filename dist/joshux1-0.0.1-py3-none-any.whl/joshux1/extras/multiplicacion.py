def mult (x,x2):
    return x*x2