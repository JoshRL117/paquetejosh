def div (x,x2):
    if x2 !=0:
        return x/x2