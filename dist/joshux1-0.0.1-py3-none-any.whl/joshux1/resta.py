def resta (x,y):
    return x-y